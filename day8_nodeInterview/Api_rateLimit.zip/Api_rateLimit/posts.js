const posts = [
  {
    userId: 1,
    id: 1,
    title: "entrance of rate api",
    body: "the limitation takes place",
  },
  {
    userId: 1,
    id: 2,
    title: "testing the api",
    body: "whether working or not?",
  },
  {
    userId: 1,
    id: 3,
    title: "fetching the api",
    body: "data appear",
  },
  {
    userId: 4,
    id: 1,
    title: "using async",
    body: "consume the data",
  },
];

module.exports = posts;
